# FluidPropertiesInterrogator System

The `FluidPropertiesInterrogator` syntax is used with
[AddFluidPropertiesInterrogatorAction](/AddFluidPropertiesInterrogatorAction.md).

!syntax list /FluidPropertiesInterrogator objects=True actions=False subsystems=False

!syntax list /FluidPropertiesInterrogator objects=False actions=False subsystems=True

!syntax list /FluidPropertiesInterrogator objects=False actions=True subsystems=False
