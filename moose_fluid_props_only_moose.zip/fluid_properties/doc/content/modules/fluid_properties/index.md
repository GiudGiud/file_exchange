# Fluid Properties Module

The Fluid Properties module provides the [FluidProperties System](syntax/FluidProperties/index.md]),
as well as various classes to support it.

!syntax complete groups=FluidPropertiesApp
