!template load file=sqa/app_index.md.template category=fluid_properties app=Fluid Properties

!template item key=sqa-report
!sqa report category={{category}}
