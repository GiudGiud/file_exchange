# NaNInterface

For some objects it is desirable to continue running despite generation of
NaN(s). This class provides an interface for choosing whether to throw an error,
a warning, or nothing at all, just using a quiet NaN.
