# RhoVaporMixtureFromPressureTemperatureIC

Initial condition to set density of vapor mixture from given pressure and temperature using the
`SinglePhaseFluidProperties` and `VaporMixtureInterface` interface.

!syntax parameters /ICs/RhoVaporMixtureFromPressureTemperatureIC

!syntax inputs /ICs/RhoVaporMixtureFromPressureTemperatureIC

!syntax children /ICs/RhoVaporMixtureFromPressureTemperatureIC
