# SpecificEnthalpyFromPressureTemperatureIC

Initial condition to set specific enthalpy from given pressure and temperature using the
`SinglePhaseFluidProperties` interface.

!syntax parameters /ICs/SpecificEnthalpyFromPressureTemperatureIC

!syntax inputs /ICs/SpecificEnthalpyFromPressureTemperatureIC

!syntax children /ICs/SpecificEnthalpyFromPressureTemperatureIC

!bibtex bibliography
