# AddFluidPropertiesInterrogatorAction

!syntax description /FluidPropertiesInterrogator/AddFluidPropertiesInterrogatorAction

This action performs a number of tasks needed to use [FluidPropertiesInterrogator](/FluidPropertiesInterrogator.md)
in a minimal setting; it creates a dummy mesh, executioner, and problem, and it
creates a console output for the printing performed by the interrogator.

!syntax parameters /FluidPropertiesInterrogator/AddFluidPropertiesInterrogatorAction

!bibtex bibliography
