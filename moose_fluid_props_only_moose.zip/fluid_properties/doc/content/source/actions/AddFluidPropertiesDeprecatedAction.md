# AddFluidPropertiesDeprecatedAction

This action adds fluid properties from the `[Modules/FluidProperties]` block.

!alert note
As the name suggests, this action is deprecated. Do not rely on it and convert your inputs to using the
non-nested `[FluidProperties]` block instead.

!syntax parameters /Modules/FluidProperties/AddFluidPropertiesDeprecatedAction

!syntax inputs /Modules/FluidProperties/AddFluidPropertiesDeprecatedAction

!syntax children /Modules/FluidProperties/AddFluidPropertiesDeprecatedAction
