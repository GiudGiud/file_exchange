# TemperatureAux

!syntax description /AuxKernels/TemperatureAux

Calculates the temperature given specific volume and specific internal energy.

!syntax parameters /AuxKernels/TemperatureAux

!syntax inputs /AuxKernels/TemperatureAux

!syntax children /AuxKernels/TemperatureAux

!bibtex bibliography
